package com.kirtik.foodrunner.model

data class OrderItem(
    val foodName:String,
    val foodPrice:String
)