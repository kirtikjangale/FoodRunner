package com.kirtik.foodrunner.model

data class FoodItem (
    val itemId:String,
    val itemName:String,
    val itemCost:String,
    val resId:String
)